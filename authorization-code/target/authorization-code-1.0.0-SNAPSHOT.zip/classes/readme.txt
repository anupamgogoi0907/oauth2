### Get Access Token ###
http://localhost:8081/api/authorize?response_type=code&client_id=mule&redirect_uri=http://localhost:8081/response&scope=READ_RESOURCE

### Validate ###