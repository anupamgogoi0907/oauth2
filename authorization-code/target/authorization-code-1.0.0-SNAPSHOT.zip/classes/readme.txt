### Get Access Token ###
http://localhost:8081/api/authorize?response_type=code&client_id=mule&redirect_uri=http://localhost:8081/response&scope=READ_RESOURCE

### Validate ###
http://localhost:8081/validate?access_token=NTUkDO2fEPaMckESAExGxRsi_9LdoJjASoFoDR4obdnLOveSNkmbuhoFP8UqFKkjAOBfCGuRsub-QnKx99U3uA